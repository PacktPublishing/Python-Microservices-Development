Strava Worker
=============

Celery worker that gets runs from Strava to push
then into Dataservice.
