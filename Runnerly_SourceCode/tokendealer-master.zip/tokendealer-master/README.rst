tokendealer
----------

Microservices that:

- generates JWT tokens given a payload
- verify a JWT token signature
- expose the public key used for the signing
