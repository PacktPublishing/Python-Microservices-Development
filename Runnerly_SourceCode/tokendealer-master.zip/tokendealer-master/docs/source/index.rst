===========
TokenDealer
===========

The **TokenDealer** microservice generates and checks JWT tokens.



.. toctree::
   :maxdepth: 2

   api
