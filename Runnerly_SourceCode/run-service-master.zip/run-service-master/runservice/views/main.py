from flask import Blueprint
from runservice.database import db, User

main = Blueprint('home', __name__)


@main.route("/")
def _index():
    count = db.session.query(User).count()
    return {'users': count}
