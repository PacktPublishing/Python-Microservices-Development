from .main import main

blueprints = [main]
