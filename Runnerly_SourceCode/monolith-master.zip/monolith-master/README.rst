Monolithic Version
==================


