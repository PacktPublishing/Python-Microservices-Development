from myservice.views.home import home


blueprints = [home]
