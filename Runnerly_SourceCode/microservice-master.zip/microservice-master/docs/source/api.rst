APIS
====


**myservice** includes one view that's linked to the root path:

.. autofunction:: myservice.views.home.index
