microservice
============

This project is a template for building microservices with Flask.

.. image:: https://coveralls.io/repos/github/tarekziade/microservice/badge.svg?branch=master
   :target: https://coveralls.io/github/tarekziade/microservice?branch=master

.. image:: https://travis-ci.org/tarekziade/microservice.svg?branch=master
   :target: https://travis-ci.org/tarekziade/microservice

.. image:: https://readthedocs.org/projects/microservice/badge/?version=latest
   :target: https://microservice.readthedocs.io




